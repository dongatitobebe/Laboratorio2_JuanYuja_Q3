#include "cframe.h"
#include "ui_cframe.h"

cframe::cframe(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::cframe)
{
    ui->setupUi(this);
    // Llamado de combobox parte1
    connect(ui->comboBox, QOverload<int>::of(&QComboBox::activated),
            this, &cframe::on_comboBox_activated);

    connect(ui->convertirletra_binario, &QPushButton::clicked, this, &cframe::on_convertirletra_binario_clicked);
    connect(ui->convertirletra_decimal, &QPushButton::clicked, this, &cframe::on_convertirletra_decimal_clicked);
    connect(ui->convertirletra_hexa, &QPushButton::clicked, this, &cframe::on_convertirletra_hexa_clicked);
    connect(ui->convertirbinario_letra, &QPushButton::clicked, this, &cframe::on_convertirbinario_letra_clicked);
    connect(ui->convertirdecimal_letra, &QPushButton::clicked, this, &cframe::on_convertirdecimal_letra_clicked);
    connect(ui->convertirhexa_letra, &QPushButton::clicked, this, &cframe::on_convertirhexa_letra_clicked);
}

cframe::~cframe()
{
    delete ui;
}

// Botones
void cframe::on_pushButton_4_clicked()
{
    int num = ui->SB_ingresenum->value();
    Generar_triangulo(num);
}

// Ejercicio 2
void cframe::Generar_triangulo(int n)
{
    QString Triangulo;

    for (int i = 1; i <= n; ++i)
    {
        QString line;

        for (int espacios = 0; espacios < n - i; ++espacios)
        {
            line += " ";
        }

        for (int asteriscos = 0; asteriscos < (2 * i - 1); ++asteriscos)
        {
            line += "*";
        }

        Triangulo += line + "\n";
    }

    ui->Mostrar_triangulo->setText(Triangulo);
}

// Botones
void cframe::on_pushButton_clicked()
{
    ui->stackedWidget->setCurrentIndex(0);
}

void cframe::on_pushButton_2_clicked()
{
    ui->stackedWidget->setCurrentIndex(1);
}

void cframe::on_Salir_clicked()
{
    QApplication::quit();
}

// Ejercicio 3
void cframe::on_pushButton_5_clicked()
{
    QString numTarjeta = ui->lineEdit->text().replace(" ", "");
    bool esValido = VerificarNumeroTarjeta(numTarjeta);
    if (esValido) {
        ui->textEdit_2->setText("Número de tarjeta válido");
    } else {
        ui->textEdit_2->setText("Número de tarjeta inválido");
    }
}

bool cframe::VerificarNumeroTarjeta(const QString& numTarjeta)
{
    int cantDigitos = numTarjeta.length();
    int sumaTotal = 0;
    bool esSegundo = false;

    for (int i = cantDigitos - 1; i >= 0; i--) {
        int digito = numTarjeta[i].digitValue();

        if (esSegundo) {
            digito *= 2;

            if (digito > 9) {
                digito = (digito / 10) + (digito % 10);
            }
        }

        sumaTotal += digito;

        esSegundo = !esSegundo;
    }

    return (sumaTotal % 10 == 0);
}

// Botón
void cframe::on_pushButton_3_clicked()
{
    ui->stackedWidget->setCurrentIndex(2);
}

// Llamado del combobox parte2
void cframe::on_comboBox_activated(int index)
{
    ui->stackedWidget_2->setCurrentIndex(index);
}

void cframe::on_convertirletra_binario_clicked()
{
    QString letra = ui->ingresarletra_binario->text();
    if (letra.length() != 1) {
        ui->mostrarletra_binario->setText("Ingrese un solo carácter.");
        return;
    }

    QChar caracter = letra.at(0);
    QString binario = QString::number(caracter.unicode(), 2).rightJustified(8, '0');

    ui->mostrarletra_binario->setText(binario);
}

void cframe::on_convertirletra_decimal_clicked()
{
    QString letra = ui->ingresarletra_decimal->text();
    if (letra.length() != 1) {
        ui->mostrarletra_decimal->setText("Ingrese un solo carácter.");
        return;
    }

    QChar caracter = letra.at(0);
    int decimal = caracter.unicode();
    ui->mostrarletra_decimal->setText(QString::number(decimal));
}

void cframe::on_convertirletra_hexa_clicked()
{
    QString letra = ui->ingresarletra_hexa->text();
    if (letra.length() != 1) {
        ui->mostrarletra_hexa->setText("Ingrese un solo carácter.");
        return;
    }

    QChar caracter = letra.at(0);
    QString hexadecimal = QString::number(caracter.unicode(), 16).toUpper();

    ui->mostrarletra_hexa->setText(hexadecimal);
}

void cframe::on_convertirbinario_letra_clicked()
{
    QString binario = ui->ingresarbinario_letra->text();
    bool ok1;
    int decimal = binario.toInt(&ok1, 2);
    if (!ok1) {
        ui->mostrarbinario_letra->setText("Formato binario inválido.");
        return;
    }

    QChar caracter(decimal);
    ui->mostrarbinario_letra->setText(caracter);
}

void cframe::on_convertirdecimal_letra_clicked()
{
    QString decimalStr = ui->ingresardecimal_letra->text();
    bool ok2;
    int decimal = decimalStr.toInt(&ok2);

    if (!ok2) {
        ui->mostrardecimal_letra->setText("Formato decimal inválido.");
        return;
    }

    QChar caracter(decimal);
    ui->mostrardecimal_letra->setText(caracter);
}

void cframe::on_convertirhexa_letra_clicked()
{
    QString hexadecimal = ui->ingresarhexa_letra->text().toUpper();
    bool ok3;
    int decimal = hexadecimal.toInt(&ok3, 16);
    if (!ok3) {
        ui->mostrarhexa_letra->setText("Formato hexadecimal inválido.");
        return;
    }

    QChar caracter(decimal);
    ui->mostrarhexa_letra->setText(caracter);
}
